#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "bird.h"
#include "scene.h"
#include <QTimer>
#include <memory>
#include <iomanip>
#include <QKeyEvent>




MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    Bird = new QWidget(ui->centralwidget);
    Bird->setGeometry(100, 200, 30, 30);
    Bird->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 42, 255);"));
    Bird->show();
    std::vector <bird> birds(1);
    mainScene = new Scene(birds);
    timer = new QTimer;
    connect(timer, SIGNAL(timeout()), this, SLOT(slotTimerAlarm()));
    timer->start(5);
}


void MainWindow::importInfo() {
    auto b = mainScene->getBirds();
    Bird->move(b[0].x, b[0].y);
    ui->tube1->move(mainScene->get_Tube1x(), mainScene->get_Tube1y());
    ui->tube2->move(mainScene->get_Tube2x(), mainScene->get_Tube2y());
    cs = (mainScene->get_cur_score() + 2600) / 4000;
    ui->label->setText(QString::number(cs));
}
void MainWindow::slotTimerAlarm() {
    importInfo();
    mainScene->do_smth();
}
void MainWindow::keyPressEvent(QKeyEvent *event) {
    if (event->key() == Qt::Key_D) {
        mainScene->m_birds[0].need_to_jump = true;
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

