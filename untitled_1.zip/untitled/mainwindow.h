#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#pragma once
#include <QMainWindow>
#include <QRandomGenerator>

#include <iostream>
#include <random>
#include <scene.h>
//#include <random.h>
#include <ctime>
#include <memory>
//#include <vector>
//#include <algorithm>
//
//#include <cmath>
//#include <fstream>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
class QRandomGenerator;
QT_END_NAMESPACE
class MainWindow : public QMainWindow
{
    Q_OBJECT;

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void keyPressEvent(QKeyEvent *event);
    void slotTimerAlarm();

private:
    void importInfo();
    Ui::MainWindow *ui;
    Scene *mainScene;
    QTimer *timer;
    bird *mainBird;
    QWidget *Bird;
    int cs = 0;
};
#endif // MAINWINDOW_H
